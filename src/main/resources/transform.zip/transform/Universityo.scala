package com.qiaobutang.resume.transform

import net.liftweb.common.Loggable
import com.qiaobutang.resume.util.JsonHelpers.jsonParser
import net.liftweb.json.{JObject, JString, JField}
import net.liftweb.json.JsonAST.{JArray, JInt}
import com.qiaobutang.resume.{Config, Boot}
import com.qiaobutang.resume.model.{ University => UniversityModel, College => CollegeModel }
import com.mongodb.MongoOptions
import net.liftweb.mongodb.{MongoHost, MongoAddress, MongoDB}

/**
 * Created by mark on 3/7/14.
 */
object Universityo extends App with Loggable {
	val fileName = "./src/main/scala/com/qiaobutang/resume/transform/allunivlist.json"
	val second = "./src/main/scala/com/qiaobutang/resume/transform/countryMapMerged.json"
	val third = "./src/main/scala/com/qiaobutang/resume/transform/renren_colleage.json"
	val utf8 = "UTF-8"

	val json = jsonParser.parse(scala.io.Source.fromFile(fileName).mkString)
	val second_json =  jsonParser.parse(scala.io.Source.fromFile(second).mkString)
	val third_json =  jsonParser.parse(scala.io.Source.fromFile(third).mkString)
	logger.debug(s"fileName:json:: ${json.children}")

	val coun = second_json.children map {case JObject(c) =>
		val JField(_, JString(id)) = c.head
		val JField(_, JString(name)) = c.last
		id -> name
	}
	logger.debug(s"country:json:: $coun")

	val countries = JsonParserCn2.wo3.countries
	logger.debug(s"country:json:: $countries")
//	val colleges = Renren.getFaculties.flatten.flatten.groupBy(_._1)
	val colleges = third_json.children flatMap {
	case JObject(col) =>
		val JField(_,JInt(sc_id)) = col.head
		val JField(_,JString(sc_name)) =col.take(2).last
		val JField(_,JArray(sc_cols)) = col.last
		var count = 1
		val ct = sc_cols map {  case JString(n)  =>
			count = count + 1
			(sc_id, sc_name, n, count)
		}
//		logger.debug(s"country:json:: $sc_id)")
//		logger.debug(s"country:json:: $sc_name)")
//		logger.debug(s"country:json:: $sc_cols")
		ct
	case _ =>  ???
} groupBy(_._1)

	def ctreateUniversity = json.children collect {
		case JObject(l) => {
			val JString(name) = l.find(_.name.equals("name")).headOption.map{_.value}.getOrElse(JString(""))
			logger.debug(s"name::$name")

			val (country_key, states) =countries.find(_.country.value.equals(name)).headOption.map(c => c.country.key -> c.states).getOrElse("" -> Nil)
			logger.debug(s"key::$country_key")
			val univs_c = l.find(_.name.equals("univs")).headOption.map{_.value.children map{case JObject(sc) =>
				val JString(sc_name) = sc.last.value
				val JInt(sc_id) = sc.head.value
				sc_id -> sc_name
			}}.getOrElse(Nil)
			logger.debug(s"name::$univs_c")

			val state = l.find(_.name.equals("provs")).headOption.map{_.value.children collect {
				case JObject(s) =>{
					val JString(name) = s.find(_.name.equals("name")).headOption.map{_.value}.getOrElse(JString(""))
					val univs_s = s.find(_.name.equals("univs")).headOption.map{_.value.children map{case JObject(sc) =>
						val JString(sc_name) = sc.last.value
						val JInt(sc_id) = sc.head.value
						sc_id -> sc_name
					}}.getOrElse(Nil)
					//val univs = if(univs_c.nonEmpty) univs_c else if(univs_s.nonEmpty) univs_s else Nil
					logger.debug(s"name::$univs_s")
					val (state_key, cities) = states.find(_.state.value.equals(name)).headOption.map(c => c.state.key -> c.cities).getOrElse("" -> Nil)
					val tuples = univs_s.map{ u =>
						logger.debug(s"country_key::$country_key ::state_key::$state_key::univs_name::::${u._1}:::univs_id::::${u._2}")
						val sort_id = (u._1 * 100).toInt
						val un = UniversityModel.createRecord.name(u._2).country_id(country_key).state_id(state_key).sort(sort_id)
						if(country_key.equals("CHS")) colleges.get(u._1) map {
							_ map {
								c =>
									CollegeModel.createRecord.name(c._3).university_id(un.idValue).sort(c._4 * 1000).save_!
							}
						}
					     un.save_!
						(country_key,state_key, u._1, u._2)
					}

				}
			}
			}

			val tuples = univs_c.map{c =>
				logger.debug(s"country_key::$country_key ::state_key:: null ::univs_id::::${c._1} ::univs_id::::${c._2}")
				val sort_id = (c._1 * 100).toInt
				UniversityModel.createRecord.name(c._2).country_id(country_key).sort(sort_id).save_!
				(country_key,"", c)
			}

			//      val state_id = states.map{_.map(_.find(_.value.equals("name")))}
			logger.debug(s"state::$state")

			JObject(JField("country_id",JString(country_key)) :: l)
		}
	}

	initModel
	ctreateUniversity
	def initModel {
		val mongoConfig = Config.Mongo

		val mongoOptions = new MongoOptions
		mongoOptions.connectionsPerHost = mongoConfig.connectionsPerHost
		mongoOptions.threadsAllowedToBlockForConnectionMultiplier =
		mongoConfig.threadsAllowedToBlockForConnectionMultiplier

		MongoDB.defineDb(
			mongoConfig.DefaultMongoIdentifier,
			MongoAddress(MongoHost(mongoConfig.host, mongoConfig.port, mongoOptions), mongoConfig.db)
		)
	}
//	def mergeCountry = second_json transform {
//		case JObject(l) => {
//			val JString(name) = l.last.value //take easy with location, lazy, eh
//
//			val key =country.keys.find(_.value.equals(name)).get.key
//
//			JObject(JField("key",JString(key)) :: l)
//		}
//	}

//
//	def toJson = compact(render(decompose(mergeCountry)))
//	val outfileName = "./src/main/scala/com/markhuyong/countryMapMerged.json"
//	logger.debug(s"mergeCountry:json:: $mergeCountry")
	//   val merged = country map {
	//
	//   }
}
