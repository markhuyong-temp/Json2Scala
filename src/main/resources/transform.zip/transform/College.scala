package com.qiaobutang.resume.transform

import net.liftweb.common.Loggable
import java.util.regex.Pattern
import net.liftweb.json._
import net.liftweb.mongodb.BsonDSL._
import net.liftweb.mongodb.{MongoHost, MongoDB}
import com.mongodb.{BasicDBObjectBuilder, MongoOptions}
import com.qiaobutang.resume.model.{ University => UniversityModel, College => CollegeModel }
import net.liftweb.mongodb.MongoAddress
import com.qiaobutang.resume.Config

object College extends App with Loggable {
	val fileName = "./src/main/scala/com/qiaobutang/resume/transform/allunivlist.json"
	val second = "./src/main/scala/com/qiaobutang/resume/transform/baikeAllUnivs.json"
	val third = "./src/main/scala/com/qiaobutang/resume/transform/renren_colleage.json"
	val utf8 = "UTF-8"

	val json = parse(scala.io.Source.fromFile(fileName).mkString)
	val second_json =  parse(scala.io.Source.fromFile(second).mkString)
	val third_json =parse(scala.io.Source.fromFile(third).mkString)
//	logger.debug(s"fileName:json:: ${json.children}")

	initModel
	var count =0
	val coun = second_json.children map {case JObject(c) =>
		val JField(_, JString(s_id)) = c.head
		val JField(_, JString(s_name)) = c.drop(1).head
		val JField(_, JString(s_engname)) = c.drop(2).head
		val JField(_, JString(s_abbr)) = c.drop(3).head
		val JField(_, JString(s_engabbr)) = c.drop(4).head
		val JField(_, JString(s_tags)) = c.drop(5).head
		val JField(_, JString(s_props)) = c.last
		val abbr = getSplit(s_abbr).filterNot(_.matches("\\w+"))
		val abbr_en = getSplit(s_abbr).filter(_.matches("\\w+"))
		val tags = getSplit(s_tags).filterNot(_.equals(""))
		val props = getSplit(s_props)//.filterNot(_.trim.matches("\\s+"))
		val com_tags = (tags ::: props).distinct //if(tags.nonEmpty && !tags.forall(_.equals("")))(tags ::: props).distinct  else props.distinct

		//logger.debug("abbr=="+ abbr )
		//logger.debug("com_tags=="+ com_tags )

		val box = UniversityModel.findAll("sort",s_id.toInt * 100)
		val query = ("sort" -> s_id.toInt * 100 )
		val updates = ("$set" -> ("name_en" -> s_engname) ~ ("abbr" -> abbr)~ ("abbr_en" -> abbr_en)~ ("tags" -> com_tags))
		UniversityModel.update(query, updates)

		val f = box.isEmpty
		val size = box.size
		//if(size>2) logger.debug("size>1"+size );
		//if(f) {count =count +1; logger.debug("universicty_name =::" + s_name +" ,count=" + count );}
		//if(size == 1) {count =count +1; logger.debug("size =::" + s_name +" ,count=" + count );}
		//s_name  -> tags                     ,
	}
	def getSplit(str: String) = str.trim.replaceAll("或","-").replaceAll(",","-")
	.replaceAll("英文缩写","-").replaceAll("英：","-").replaceAll("1985年","-").replaceAll("南“北大”","南北大")
	.split("[\\”\\“,、 \\(\\)（），；\\.：/-]+").toList//.distinct
//	def getSplit(str: String) = str.trim.split("[,、\\(\\)（）/-或]+").filterNot(c => c.equals("")||c.equals("(")||c.equals(")")).toList.distinct
//	val coun = second_json.children map {case JObject(c) =>
//		val JField(_, JString(s_name)) = c.head
//		val JField(_, JString(tags)) = c.last
//		val JField(_, JString(abbr)) = c.drop(2).head
//		val test = abbr.trim.split("[,、， ()（）/-]").filterNot(c => c.equals("")||c.equals("(")||c.equals(")")).toList
//		val s_c_s = s_name.trim.split("[,、， ()（）/-]").filterNot(c => c.equals("")||c.equals("(")||c.equals(")")).toList
//		val max = s_c_s.find(_.length > 3).headOption.getOrElse("Null")
//		val balance = s_name.replace("大学","大") :: s_name.replace("学院","") ::s_name.replace("农业大学","农大")::
//		s_name.replace("师范大学","师大"):: s_name.replace("师范学院","师院")::Nil //s_name.substring(2)::s_name.substring(3):: Nil
//
//		val total = (test ::: s_c_s ::: balance).filterNot(_.equals("大学")).filterNot(_.equals("学")).
//		filterNot(_.equals("师院")). filterNot(_.equals("师大")).filterNot(_.equals("师范大学")). filterNot(_.equals("师范学院")).distinct
//
//		val restr = total.reduceLeft(_ +"|"+ _)
////		val pa = Pattern.compile("("+ restr  + ")" , Pattern.CASE_INSENSITIVE)
//		val b = BasicDBObjectBuilder.start.add("name", s_name).get
////		val qry =s"\"name\":{\$regex:\"${s_name.trim}\""}
//		val box = UniversityModel.findAll(b)
//
//		val f = box.isEmpty
//		val size = box.size
//		if(size>2) logger.debug("size>1"+size );
//		if(f) {count =count +1; logger.debug("universicty_name =::" + s_name +" ,count=" + count );}
//		s_name  -> tags
//	}
//	logger.debug(s"country:json:: $coun")

//	val countries = JsonParserCn2.wo3.countries
////	logger.debug(s"country:json:: $countries")
//	//	val colleges = Renren.getFaculties.flatten.flatten.groupBy(_._1)
//	val colleges = third_json.children flatMap {
//		case JObject(col) =>
//			val JField(_,JInt(sc_id)) = col.head
//			val JField(_,JString(sc_name)) =col.take(2).last
//			val JField(_,JArray(sc_cols)) = col.last
//			var count = 1
//			val ct = sc_cols map {  case JString(n)  =>
//				count = count + 1
//				(sc_id, sc_name, n, count)
//			}
//			//		logger.debug(s"country:json:: $sc_id)")
//			//		logger.debug(s"country:json:: $sc_name)")
//			//		logger.debug(s"country:json:: $sc_cols")
//			ct
//		case _ =>  ???
//	} groupBy(_._1)
//
//	def ctreateUniversity = json.children collect {
//		case JObject(l) => {
//			val JString(name) = l.find(_.name.equals("name")).headOption.map{_.value}.getOrElse(JString(""))
//			logger.debug(s"name::$name")
//
//			val (country_key, states) =countries.find(_.country.value.equals(name)).headOption.map(c => c.country.key -> c.states).getOrElse("" -> Nil)
//			logger.debug(s"key::$country_key")
//			val univs_c = l.find(_.name.equals("univs")).headOption.map{_.value.children map{case JObject(sc) =>
//				val JString(sc_name) = sc.last.value
//				val JInt(sc_id) = sc.head.value
//				sc_id -> sc_name
//			}}.getOrElse(Nil)
//			logger.debug(s"name::$univs_c")
//
//			val state = l.find(_.name.equals("provs")).headOption.map{_.value.children collect {
//				case JObject(s) =>{
//					val JString(name) = s.find(_.name.equals("name")).headOption.map{_.value}.getOrElse(JString(""))
//					val univs_s = s.find(_.name.equals("univs")).headOption.map{_.value.children map{case JObject(sc) =>
//						val JString(sc_name) = sc.last.value
//						val JInt(sc_id) = sc.head.value
//						sc_id -> sc_name
//					}}.getOrElse(Nil)
//					//val univs = if(univs_c.nonEmpty) univs_c else if(univs_s.nonEmpty) univs_s else Nil
//					logger.debug(s"name::$univs_s")
//					val (state_key, cities) = states.find(_.state.value.equals(name)).headOption.map(c => c.state.key -> c.cities).getOrElse("" -> Nil)
//					val tuples = univs_s.map{ u =>
//						logger.debug(s"country_key::$country_key ::state_key::$state_key::univs_name::::${u._1}:::univs_id::::${u._2}")
//						val sort_id = (u._1 * 100).toInt
//						val un = UniversityModel.createRecord.name(u._2).country_id(country_key).state_id(state_key).sort(sort_id)
//						if(country_key.equals("CHS")) colleges.get(u._1) map {
//							_ map {
//								c =>
//									CollegeModel.createRecord.name(c._3).university_id(un.idValue).sort(c._4 * 1000).save_!
//							}
//						}
//						un.save_!
//						(country_key,state_key, u._1, u._2)
//					}
//
//				}
//			}
//			}
//
//			val tuples = univs_c.map{c =>
//				logger.debug(s"country_key::$country_key ::state_key:: null ::univs_id::::${c._1} ::univs_id::::${c._2}")
//				val sort_id = (c._1 * 100).toInt
//				UniversityModel.createRecord.name(c._2).country_id(country_key).sort(sort_id).save_!
//				(country_key,"", c)
//			}
//
//			//      val state_id = states.map{_.map(_.find(_.value.equals("name")))}
//			logger.debug(s"state::$state")
//
//			JObject(JField("country_id",JString(country_key)) :: l)
//		}
//	}


//	ctreateUniversity
	def initModel {
		val mongoConfig = Config.Mongo

		val mongoOptions = new MongoOptions
		mongoOptions.connectionsPerHost = mongoConfig.connectionsPerHost
		mongoOptions.threadsAllowedToBlockForConnectionMultiplier =
		mongoConfig.threadsAllowedToBlockForConnectionMultiplier

		MongoDB.defineDb(
			mongoConfig.DefaultMongoIdentifier,
			MongoAddress(MongoHost(mongoConfig.host, mongoConfig.port, mongoOptions), mongoConfig.db)
		)
	}
}
